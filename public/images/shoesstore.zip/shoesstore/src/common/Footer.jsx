import React from 'react';

const Footer = () => {
  return (
    <>
      <div className='section_footer'>
        <div className='container'>
          <div className='mail_section'>
            <div className='row'>
              <div className='col-sm-6 col-lg-2'>
                <div>
                  <a href='www.aliyu.com'>
                    <img src='images/footer-logo.png' alt='' />
                  </a>
                </div>
              </div>
              <div className='col-sm-6 col-lg-2'>
                <div className='footer-logo'>
                  <img src='images/phone-icon.png' alt='' />
                  <span className='map_text'>(71) 1234567890</span>
                </div>
              </div>
              <div className='col-sm-6 col-lg-3'>
                <div className='footer-logo'>
                  <img src='images/email-icon.png' alt='' />
                  <span className='map_text'>Demo@gmail.com</span>
                </div>
              </div>
              <div className='col-sm-6 col-lg-3'>
                <div className='social_icon'>
                  <ul>
                    <li>
                      <a href='www.aliyu.com'>
                        <img src='images/fb-icon.png' alt='' />
                      </a>
                    </li>
                    <li>
                      <a href='www.aliyu.com'>
                        <img src='images/twitter-icon.png' alt='' />
                      </a>
                    </li>
                    <li>
                      <a href='www.aliyu.com'>
                        <img src='images/in-icon.png' alt='' />
                      </a>
                    </li>
                    <li>
                      <a href='www.aliyu.com'>
                        <img src='images/google-icon.png' alt='' />
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div className='col-sm-2'></div>
            </div>
          </div>
          <div className='footer_section_2'>
            <div className='row'>
              <div className='col-sm-4 col-lg-2'>
                <p className='dummy_text'>
                  {' '}
                  ipsum dolor sit amet, consectetur ipsum dolor sit amet,
                  consectetur ipsum dolor sit amet,
                </p>
              </div>
              <div className='col-sm-4 col-lg-2'>
                <h2 className='shop_text'>Address </h2>
                <div className='image-icon'>
                  <img src='images/map-icon.png' alt='' />
                  <span className='pet_text'>
                    No 40 Baria Sreet 15/2 NewYork City, NY, United Kingdom.
                  </span>
                </div>
              </div>
              <div className='col-sm-4 col-md-6 col-lg-3'>
                <h2 className='shop_text'>Our Company </h2>
                <div className='delivery_text'>
                  <ul>
                    <li>Delivery</li>
                    <li>Legal Notice</li>
                    <li>About us</li>
                    <li>Secure payment</li>
                    <li>Contact us</li>
                  </ul>
                </div>
              </div>
              <div className='col-sm-6 col-lg-3'>
                <h2 className='adderess_text'>Products</h2>
                <div className='delivery_text'>
                  <ul>
                    <li>Prices drop</li>
                    <li>New products</li>
                    <li>Best sales</li>
                    <li>Contact us</li>
                    <li>Sitemap</li>
                  </ul>
                </div>
              </div>
              <div className='col-sm-6 col-lg-2'>
                <h2 className='adderess_text'>Newsletter</h2>
                <div className='form-group'>
                  <input
                    type='text'
                    className='enter_email'
                    placeholder='Enter Your email'
                    name='Name'
                  />
                </div>
                <button className='subscribr_bt'>Subscribe</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className='copyright'>
        2022 All Rights Reserved. <a href='https://html.design'>AUCODE</a>
      </div>
    </>
  );
};

export default Footer;
