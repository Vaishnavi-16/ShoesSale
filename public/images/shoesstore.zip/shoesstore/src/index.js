import React from 'react';
import ReactDOM from 'react-dom/client';

import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Home from './components/Home';
import Collection from './pages/Collection';
import Shoes from './pages/Shoes';
import RacingBoots from './pages/RacingBoots';
import Contact from './pages/Contact';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route index element={<Home />} />
        <Route path='shoes' element={<Shoes />} />
        <Route path='racingboots' element={<RacingBoots />} />
        <Route path='contact' element={<Contact />} />
        <Route path='collection' element={<Collection />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
